package com.vti.loship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoshipApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoshipApplication.class, args);
	}

}
